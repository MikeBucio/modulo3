//modulos
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
//componentes
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { TeoriaDesicionComponent } from './teoria-desicion/teoria-desicion.component';
import { ComponentsRoutingModule } from './components-routing.module';

const COMPONENTS = [HomeComponent, TeoriaDesicionComponent];

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    ComponentsRoutingModule,
  ],
  declarations: [...COMPONENTS],
  exports: [ReactiveFormsModule, ...COMPONENTS],
})
export class ComponentsModule {}
