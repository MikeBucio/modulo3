import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-teoria-desicion',
  templateUrl: './teoria-desicion.component.html',
  styleUrls: ['./teoria-desicion.component.scss'],
})
export class TeoriaDesicionComponent implements OnInit {
  formTeoriaDecision: FormGroup;
  constructor() {}

  ngOnInit(): void {
    this.crearFormulario();
  }

  crearFormulario() {
    this.formTeoriaDecision = new FormGroup({
      opcion1: new FormControl('', Validators.required),
      opcion2: new FormControl('', Validators.required),
      opcion3: new FormControl('', Validators.required),
      opcion4: new FormControl('', Validators.required),
      //GB: gananciaBaja GM: gaanciaMedia GA: gananciaAlta
      GBOpcion1: new FormControl('', Validators.required),
      GMOpcion1: new FormControl('', Validators.required),
      GAOpcion1: new FormControl('', Validators.required),

      GBOpcion2: new FormControl('', Validators.required),
      GMOpcion2: new FormControl('', Validators.required),
      GAOpcion2: new FormControl('', Validators.required),

      GBOpcion3: new FormControl('', Validators.required),
      GMOpcion3: new FormControl('', Validators.required),
      GAOpcion3: new FormControl('', Validators.required),

      GBOpcion4: new FormControl('', Validators.required),
      GMOpcion4: new FormControl('', Validators.required),
      GAOpcion4: new FormControl('', Validators.required),

      pBaja: new FormControl('', Validators.required),
      pMedia: new FormControl('', Validators.required),
      pAlta: new FormControl('', Validators.required),
    });
  }

  calcularPropbabilidad() {
    let requestRow = this.formTeoriaDecision.getRawValue();

    let rqprobabilidadOption1 =
      requestRow.pBaja * requestRow.GBOpcion1 +
      requestRow.pMedia * requestRow.GMOpcion1 +
      requestRow.pAlta * requestRow.GAOpcion1;
    let rqprobabilidadOption2 =
      requestRow.pBaja * requestRow.GBOpcion2 +
      requestRow.pMedia * requestRow.GMOpcion2 +
      requestRow.pAlta * requestRow.GAOpcion2;
    let rqprobabilidadOption3 =
      requestRow.pBaja * requestRow.GBOpcion3 +
      requestRow.pMedia * requestRow.GMOpcion3 +
      requestRow.pAlta * requestRow.GAOpcion3;
    let rqprobabilidadOption4 =
      requestRow.pBaja * requestRow.GBOpcion4 +
      requestRow.pMedia * requestRow.GMOpcion4 +
      requestRow.pAlta * requestRow.GAOpcion4;

    console.log(
      rqprobabilidadOption1,
      rqprobabilidadOption2,
      rqprobabilidadOption3,
      rqprobabilidadOption4
    );
  }
}
