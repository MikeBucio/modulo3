export interface blockWays {
  A1: boolean;
  B1: boolean;
  C1: boolean;
  A2: boolean;
  B2: boolean;
  C2: boolean;
  A3: boolean;
  B3: boolean;
  C3: boolean;
}
