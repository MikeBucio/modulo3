import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teoria-colas',
  templateUrl: './teoria-colas.component.html',
  styleUrls: ['./teoria-colas.component.scss']
})
export class TeoriaColasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
